# NBA Sports Betting Prediction Model

A statistical modeling system that predicts NBA player performance and evaluates sports betting opportunities on platforms like PrizePicks. The model uses historical player data combined with Bayesian statistical methods to generate probability-based betting recommendations.

## 🎯 Project Overview

This project demonstrates practical applications of:
- **Data Engineering**: Automated data collection from NBA APIs
- **Statistical Modeling**: Bayesian inference and probabilistic predictions
- **Database Design**: PostgreSQL schema for efficient sports data storage
- **Risk Analysis**: Expected value calculations for betting decisions

## 🚀 Features

- **Automated Data Collection**: Fetches real-time NBA player statistics
- **Predictive Modeling**: Multiple prediction strategies (simple average, weighted average, Bayesian inference)
- **Bet Evaluation**: Calculates probability distributions and expected values for over/under lines
- **Performance Tracking**: Stores historical data for model validation and improvement

## 📊 Current Capabilities

- Predict points, rebounds, and assists for NBA players
- Analyze over/under betting lines from PrizePicks
- Calculate win probabilities and expected value for each bet
- Track player performance trends over time

## 🛠️ Tech Stack

- **Python 3.9+**: Core programming language
- **PostgreSQL**: Relational database for storing player and game statistics
- **SQLAlchemy**: ORM for database operations
- **nba_api**: Official NBA statistics API wrapper
- **Pandas & NumPy**: Data manipulation and numerical computing
- **SciPy**: Statistical distributions and probability calculations

## 📁 Project Structure

```
sports_betting_model/
├── database.py           # Database schema and ORM models
├── data_collector.py     # NBA API data fetching
├── simple_model.py       # Baseline prediction models
├── requirements.txt      # Python dependencies
└── SETUP_GUIDE.md       # Detailed setup instructions
```

## 🏁 Quick Start

1. **Clone the repository**
```bash
git clone https://github.com/YOUR_USERNAME/sports-betting-model.git
cd sports-betting-model
```

2. **Set up virtual environment**
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

3. **Configure PostgreSQL database**
```bash
# Create database
createdb sports_betting

# Add credentials to .env file
echo "DATABASE_URL=postgresql://username:password@localhost/sports_betting" > .env
```

4. **Initialize database and collect data**
```bash
python database.py
python data_collector.py
```

5. **Run predictions**
```bash
python simple_model.py
```

See [SETUP_GUIDE.md](SETUP_GUIDE.md) for detailed instructions.

## 📈 Example Output

```
============================================================
Analysis for LeBron James - POINTS
============================================================

Recent 10 games:
      date opponent  points
2024-12-01      GSW    25.0
2024-11-29      OKC    31.0
2024-11-27      PHX    28.0
...

Simple Average Prediction: 26.40 ± 4.23
Weighted Average Prediction: 27.15 ± 3.89

PrizePicks Line: 24.5

Betting Analysis:
  Probability OVER: 74.3%
  Probability UNDER: 25.7%
  Expected Value (OVER): 0.132
  Expected Value (UNDER): -0.523
  RECOMMENDATION: OVER
  Confidence: 0.68 standard deviations
```

## 🔮 Roadmap

- [ ] Implement full Bayesian model with PyMC3
- [ ] Add opponent defensive rating adjustments
- [ ] Incorporate injury reports and lineup data
- [ ] Build web dashboard for visualization
- [ ] Add NFL player predictions
- [ ] Implement backtesting framework
- [ ] Add ensemble methods (combining multiple models)

## 📝 Model Methodology

### Current Implementation (v1.0)
- **Simple Average**: Mean of last N games
- **Weighted Average**: Recent games weighted more heavily (exponential decay)
- **Probability Estimation**: Normal distribution assumption for stat predictions

### Planned Improvements (v2.0)
- Bayesian hierarchical models accounting for player-specific variance
- Opponent strength adjustments based on defensive ratings
- Home/away splits and situational factors
- Rolling correlation analysis between stats

## ⚠️ Disclaimer

This project is for educational and portfolio purposes only. Sports betting involves risk, and this model should not be used for actual gambling decisions without thorough validation and understanding of the limitations. Past performance does not guarantee future results.

## 📫 Contact

**Big Shah**
- GitHub: [@YourGitHubUsername](https://github.com/YourGitHubUsername)
- LinkedIn: [Your LinkedIn](https://linkedin.com/in/yourprofile)
- Email: your.email@example.com

## 📄 License

MIT License - see LICENSE file for details

---

*Built as a demonstration of statistical modeling and data engineering skills for software engineering internship applications.*
